import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import lemonMars from "@/assets/lemon-mars.jpg";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Background image with overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${lemonMars})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-space-brown/80 via-space-brown/60 to-space-brown/90 backdrop-blur-[2px]" />
      </div>

      {/* Animated stars */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(50)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-lemon-pastel opacity-60"
            style={{
              width: Math.random() * 3 + 1 + 'px',
              height: Math.random() * 3 + 1 + 'px',
              top: Math.random() * 100 + '%',
              left: Math.random() * 100 + '%',
              animation: `glow ${Math.random() * 3 + 2}s ease-in-out infinite`,
              animationDelay: Math.random() * 2 + 's',
            }}
          />
        ))}
      </div>

      <div className="relative z-10 flex min-h-screen flex-col items-center justify-center px-4 py-12 text-center">
        <div className="max-w-4xl space-y-8">
          {/* Error code */}
          <div className="space-y-2">
            <h1 className="text-8xl font-black tracking-tighter text-lemon-yellow md:text-9xl animate-glow">
              404
            </h1>
            <p className="text-2xl font-bold text-lemon-pastel md:text-3xl">
              HOUSTON, WE HAVE A CITRUS PROBLEM
            </p>
          </div>

          {/* Main message */}
          <div className="space-y-4 rounded-2xl border-2 border-lemon-yellow/30 bg-card/80 p-8 backdrop-blur-md">
            <h2 className="text-3xl font-bold text-foreground md:text-4xl">
              Mars Has Turned Into a Lemon! 🍋
            </h2>
            <p className="mx-auto max-w-2xl text-lg text-muted-foreground md:text-xl">
              Your navigation system was set for the Red Planet, but it appears someone replaced Mars with a giant lemon. 
              We're just as confused as you are. This wasn't in the mission briefing.
            </p>
            <p className="text-base italic text-accent md:text-lg">
              (Also, the page you're looking for doesn't exist. But honestly, that's the least weird thing happening right now.)
            </p>
          </div>

          {/* Action buttons */}
          <div className="flex flex-col gap-4 sm:flex-row sm:justify-center">
            <Button
              asChild
              size="lg"
              className="bg-lemon-yellow text-primary-foreground hover:bg-lemon-yellow/90 shadow-lg hover:shadow-[0_0_30px_rgba(255,235,59,0.5)] transition-all"
            >
              <a href="/">Return to Earth (Home)</a>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-lemon-yellow/50 text-foreground hover:bg-lemon-yellow/10 hover:border-lemon-yellow transition-all"
            >
              <a href="#" onClick={(e) => { e.preventDefault(); window.history.back(); }}>
                Go Back to Previous Planet
              </a>
            </Button>
          </div>

          {/* Footer note */}
          <p className="text-sm text-muted-foreground/70">
            Mission Control has been notified. They're checking if this is some kind of cosmic prank.
          </p>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
